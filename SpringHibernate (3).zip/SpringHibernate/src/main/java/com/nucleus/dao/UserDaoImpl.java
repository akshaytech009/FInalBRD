package com.nucleus.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.controller.LoginController;
import com.nucleus.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	final static Logger LOGGER = Logger.getLogger(LoginController.class);

	@Autowired
	SessionFactory factory;

	public User addUser(User user) {

		factory.getCurrentSession().save(user);
		return user;
	}

	public void deleteUser(int id) {
		User user = new User();
		user.setId(id);
		factory.getCurrentSession().delete(user);

	}

	@SuppressWarnings("unchecked")
	public List<User> getAllUser() {

		return factory.getCurrentSession().createCriteria(User.class).list();
	}

}
